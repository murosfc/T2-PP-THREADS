package model;

public interface OperacaoInterface {
	
	public double calcular();
}
